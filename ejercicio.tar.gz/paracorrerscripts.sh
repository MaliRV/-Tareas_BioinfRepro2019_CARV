!/bin/bash 
Amalinalli Ruiz
#Este script es para correr los scripts del paso 1-5... esperemos funcione


for i in $(cat paso1.sh paso2.sh paso3.sh paso4.sh paso5.sh); do
bash $i | 
done
